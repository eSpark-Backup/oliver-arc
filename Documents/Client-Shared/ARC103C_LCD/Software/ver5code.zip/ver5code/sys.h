/**************************************************************************************************
 * \file			sys.h
 * \description		
 *
 * \date			
 * \version			1.0.1
 * \brief           
 *
 *************************************************************************************************/

#ifndef SYS_H_
#define SYS_H_

void ResetSystick(void);
uint16_t GetSystick( void );

#endif /* SYS_H_ */
