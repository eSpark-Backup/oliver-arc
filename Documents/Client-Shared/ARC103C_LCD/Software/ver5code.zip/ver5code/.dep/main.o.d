main.o: main.c lcd.h utils.h adc.h timer.h hardware.h uart.h defs.h pwm.h \
  interrupts.h

lcd.h:

utils.h:

adc.h:

timer.h:

hardware.h:

uart.h:

defs.h:

pwm.h:

interrupts.h:
