uart.o: uart.c lcd.h utils.h uart.h

lcd.h:

utils.h:

uart.h:
