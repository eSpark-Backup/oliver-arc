hardware.o: hardware.c lcd.h utils.h hardware.h defs.h uart.h timer.h \
  adc.h

lcd.h:

utils.h:

hardware.h:

defs.h:

uart.h:

timer.h:

adc.h:
