timer.o: timer.c lcd.h utils.h timer.h

lcd.h:

utils.h:

timer.h:
