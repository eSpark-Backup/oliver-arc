lcd.o: lcd.c lcd.h utils.h

lcd.h:

utils.h:
