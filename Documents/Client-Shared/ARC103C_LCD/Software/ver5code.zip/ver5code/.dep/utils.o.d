utils.o: utils.c defs.h utils.h

defs.h:

utils.h:
