adc.o: adc.c lcd.h utils.h

lcd.h:

utils.h:
