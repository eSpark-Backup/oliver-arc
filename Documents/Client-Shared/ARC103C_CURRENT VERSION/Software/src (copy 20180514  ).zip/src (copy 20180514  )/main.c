/**************************************************************************************************
 *
 * 	main.c
 *
 *  Created on: 	04 December 2016
 *  Author:     	Edward
 *
 *************************************************************************************************/
/**************************************************************************************************
 * \file			main.c
 * \description		Main
 *
 * \date			04/12/2016
 * \version			1.0
 * \brief 			initial coding
 * \other
 *
 *
 *
 *
 *************************************************************************************************/
#include <string.h>
#include <avr/io.h>
#include <stdio.h>
//#include <util/delay.h>
#include <avr/interrupt.h>

//#define DEBUG 1
#if DEBUG
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif

const char TOOL_STR_VERS[] = "Head Stepper  v1.0";
#define _NOP() do { __asm__ __volatile__ ("nop"); } while (0)

#define TRUE 		1
#define FALSE 		0

#define STX 		0x02
#define ETX 		0x03
#define STOP 		0xA0
#define LEFT 		0xA1
#define RIGHT 		0xA2
#define HOLD 		0xA3
#define HOME 		0xA4 /* Go to home position */
#define COUNT360 	0xA5 /* Return the step count from home-to-home */
#define COUNT360_RESP 	0xB5 /* Return the step count from home-to-home */
#define STEPX 		0xA6 /* Step n steps and stop */
#define RETURN_STEP 0xA7 /* Return current step value relative to home position */
#define RETURN_STEP_RESP 0xB7 /* Return current step value relative to home position */

#define ACK 		0x06
#define NAK 		0x15

/* 4.9152   38400 ubbr = 7 */
#define USART_BAUDRATE_38400 38400
#define UBRR_VALUE_38400 (((F_CPU / (USART_BAUDRATE_38400 * 16UL))) - 1)
/**************************************************************************************************
 * Prototypes
 *************************************************************************************************/
void HW_Init( void );
void StopTimer0( void );
volatile uint32_t Count360;
uint8_t direction;
volatile uint8_t rxcount;
volatile uint8_t rxflag;
volatile uint8_t rxbyte;
uint8_t rxbuffer[20];
volatile uint16_t systick;
//static uint8_t toggle = 0;

void sleepms( int ms );
/**************************************************************************************************
 * \fn 			ISR(USART_RX_vect)
 * \brief
 * \param[in]
 * \return
 *************************************************************************************************/
//ISR(USART_RX_vect)
//{
//   rxbyte = UDR;
//   rxbuffer[ rxcount++ ] = rxbyte;
//   UDR = rxbyte;
//   rxflag = TRUE;
//}

/**************************************************************************************************
 * \fn 			ISR(SIG_INTERRUPT0)
 * \brief       Head home position interrupt sensor.
 * \param[in]
 * \return
 *************************************************************************************************/
//volatile uint8_t headtrip;
//volatile uint8_t headtripstop;
//ISR(SIG_INTERRUPT0)
//{
//	headtrip = TRUE;
//	if( headtripstop == TRUE )
//	{
//		StopTimer0();
//	}
//}

//void InitINT0( void )
//{
//	GIMSK |=0x40;
//	MCUCR=0x03;
//}

//ISR(SIG_INTERRUPT1)
//{
//	headtrip = TRUE;
//	if( headtripstop == TRUE )
//	{
//		StopTimer0();
//	}
//}


/* rising edge as tab passes through sensor */
//void InitINT1( void )
//{
//	GIMSK |= 0x80;
//	MCUCR |= 0x0C;
//}
/**************************************************************************************************
 * \fn 			ISR (SIG_TIMER0_COMPA)
 * \brief
 * \param[in]
 * \return
 *************************************************************************************************/
//ISR (SIG_TIMER0_COMPA)
//{
//  static uint8_t step=0x01;
//   static uint8_t current_direction = 0;
//  static uint16_t direction_pause_time = 0;
//   /* For head positioning only */
//   Count360++;
   /* Initialise current_direction */
//   if( current_direction == 0 )
//   {
//	   current_direction = direction;
//   }

   /* Introduce mandatory pause between hard direction changes */
//   if( current_direction != direction )
 //  {
//	   /* Direction change */
//	   direction_pause_time++;
//	   if( direction_pause_time < 50 )
//	   {
//		   return;
//	   }
//	   direction_pause_time = 0;
 ///  }

 //  if ( direction == LEFT )
 //  {
//	   PORTB = step;
//	   if( step == 0x80 )
//	   {
//		step = 0x01;
//	   }
//	   else
//	   {
//		step = step << 1;
//	   }
//	   current_direction = direction;
 //  }
 //  else if( direction == RIGHT )
//   {
//	   PORTB = step;
//	   if( step == 0x01 )
//	   {
//		step = 0x80;
//	   }
//	   else
//	   {
//		step = step >> 1;
//	   }
//	   current_direction = direction;
 //  }
//   else
 //  {
//	   PORTB = 0;
 //  }
//}

/**************************************************************************************************
 * \fn 			ISR (SIG_TIMER1_COMPA)
 * \brief       System timer tick and heart-beat LED.
 * \param[in]
 * \return
 *************************************************************************************************/
//ISR (SIG_TIMER1_COMPA)
//{
//	if (toggle)
//	{
//		toggle = 0;
//	    PORTD &= ~(1 << PD6);
//	}
//	else
//	{
//		toggle = 1;
//		PORTD |=  (1 << PD6);
//	}
//	systick++;
//}


//volatile unsigned int  ms = 99;
//volatile char x;

//ISR (SIG_TIMER1_COMPA )
//{


//	OCR1A = ms;
//	if ( x )
//		ms = 200;
//	else
//		ms = 600;
//	x ^= 1;
//}

// 25 KC = 800
// 750 + 50 max

/**************************************************************************************************
 * \fn 			void USART1Init(void)
 * \brief
 * \param[in]
 * \return
 *************************************************************************************************/

void USART_Init(unsigned int ubrr)
{
 /*Set baud rate */
  UBRR0H = (unsigned char)(ubrr>>8);
  UBRR0L = (unsigned char)ubrr;
  /*Enable receiver and transmitter */
  UCSR0B = (1<<RXEN0)|(1<<TXEN0);
  /* Set frame format: 8data, 1 stop bit */
  UCSR0C = (1<<UCSZ00) | (1 << UCSZ01);
}

/**************************************************************************************************
 * \fn 			void USART1SendByte(uint8_t u8Data)
 * \brief
 * \param[in]
 * \return
 *************************************************************************************************/
void USART1SendByte(uint8_t u8Data)
{
//	uint8_t dump = UDR;
//	dump = UDR;
//
//	/* Wait while previous byte is completed */
//	while(!(UCSRA&(1<<UDRE))){};
//	/* Transmit data */
//	UDR = u8Data;
//	while(!(UCSRA&(1<<UDRE))){};
}

/**************************************************************************************************
 * \fn 			void USARTxEnableInterrupts( void
 * \brief
 * \param[in]
 * \return
 *************************************************************************************************/
void USARTxEnableInterrupts( void )
{
//	UCSRB |= (1<<RXCIE);
//	sei();
}

/**************************************************************************************************
 * \fn 			void InitTimer1( void )
 * \brief       Set timer1 for systick and heart-beat LED. Timer compare mode.
 * \param[in]
 * \return
 *************************************************************************************************/
//void InitTimer1( void )
//{
//	/* Number to count to */
//	OCR1A = 0x400;
//	/* CTC mode */
//	TCCR1A = 0;
//	/* CTC mode, clk src = clk/256 start timer */
//	TCCR1B = (1 << WGM12) | (1 << CS12);
//	 /* Enable Compare Interrupt */
//	TIMSK |= ( 1 << OCIE1A );
//}

/**************************************************************************************************
 * \fn 			void InitTimer0( void )
 * \brief       Set timer0 for stepper speed control. Timer compare mode.
 * \param[in]
 * \return
 *************************************************************************************************/
//void InitTimer0( uint8_t countto, uint8_t divider )
//{
//	/* Count to */
////	OCR0A = countto;
////	TCCR0A = 0x02;
//	/* Divider */
////	TCCR0B = divider;
//	/* Clear interrupt flag */
//	TIFR |= 0x01;
//	/* TC0 compare match A interrupt enable */
//	TIMSK |= 0x01;
//}

/**************************************************************************************************
 * \fn 		void StopTimer0( void )
 * \brief   Stop timer interrupt therefore stopping stepper.
 * \param[in]
 * \return
 *************************************************************************************************/
//void StopTimer0( void )
//{
//	/* TC0 compare match A interrupt disable */
//	TIMSK &= ~0x01;
//}
/**************************************************************************************************
 * \fn 		void ResetSystick( )
 * \brief   Reset system for count purposes.
 * \param[in]
 * \return
 *************************************************************************************************/
//void ResetSystick( )
//{
//	systick = 0;
//}

/**************************************************************************************************
 * \fn 			uint16_t GetSystick( void )
 * \brief       Get systick for count compare purposes.
 * \param[in]
 * \return
 *************************************************************************************************/
//uint16_t GetSystick( void )//
//{
//	return systick;
//}


/* Which analog pin we want to read from.  The pins are labeled "ADC0"
 * "ADC1" etc on the pinout in the data sheet.  In this case ADC_PIN
 * being 0 means we want to use ADC0.  On the ATmega328P this is also
 * the same as pin PC0 */
#define ADC_PIN			0


uint16_t adc_read(uint8_t adcx) {
	/* adcx is the analog pin we want to use.  ADMUX's first few bits are
	 * the binary representations of the numbers of the pins so we can
	 * just 'OR' the pin's number with ADMUX to select that pin.
	 * We first zero the four bits by setting ADMUX equal to its higher
	 * four bits. */
	ADMUX	&=	0xf0;
	ADMUX	|=	adcx;

	/* This starts the conversion. */
	ADCSRA |= _BV(ADSC);

	/* This is an idle loop that just wait around until the conversion
	 * is finished.  It constantly checks ADCSRA's ADSC bit, which we just
	 * set above, to see if it is still set.  This bit is automatically
	 * reset (zeroed) when the conversion is ready so if we do this in
	 * a loop the loop will just go until the conversion is ready. */
	while ( (ADCSRA & _BV(ADSC)) );

	/* Finally, we return the converted value to the calling function. */
	return ADC;
}

uint16_t ReadADC(uint8_t __channel)
{
   ADMUX = (ADMUX & 0xf0) | __channel; // Channel selection
   ADCSRA |= _BV(ADSC);                // Start conversion
   while(!bit_is_set(ADCSRA,ADIF));    // Loop until conversion is complete
   ADCSRA |= _BV(ADIF);                // Clear ADIF by writing a 1 (this sets the value to 0)

   return(ADC);
}

void adc_init()
{
	ADMUX = 0b01000000; //AVCC with external capacitor(1) at AREF pin
	ADCSRA = _BV(ADEN) | _BV(ADPS2) | _BV(ADPS1) | _BV(ADPS0); //Enable ADC and set 128 prescale
}

void sleep( int tm )
{
	long n;
	int i;

	for(i=0;i< tm; i++ )
	{
		n = 10000;
		while( n-- );
	}

}

#define HIGH 1
#define LOW 0
#define ON 1
#define OFF 0
#define FWD 1
#define REV 2
#define REEL_SLOW 3
#define REEL_FAST 4
#define REEL_REVERSE 5

void  	Marker( char mark )
{
	if( mark )
		PORTC |= _BV( PC4 );
	else
		PORTC &= ~_BV( PC4 );

}

#define NONE_ALL_OFF 0
#define RED 4
#define YELLOW 3
#define GREEN 2
// [4]LCD/Red LED. [3]LCD/Yellow LED, [2]LCD/Green LED,
void Led( char led, char mark )
{
	if ( led == RED )
	{
		if( mark )
			PORTC &= ~_BV( PC4 );
		else
			PORTC |= _BV( PC4 );
	}
	else if ( led == YELLOW )
	{
		if( mark )
			PORTC &= ~_BV( PC3 );
		else
			PORTC |= _BV( PC3 );
	}
	else if ( led == GREEN )
	{
		if( mark )
			PORTC &= ~_BV( PC2 );
		else
			PORTC |= _BV( PC2 );
	}
	else
	{
		PORTC |= _BV( PC4 );
		PORTC |= _BV( PC3 );
		PORTC |= _BV( PC2 );
	}
}

#define SPOOL 1
#define REEL 2

void PWM_Start( unsigned int val, char dir )
{
//
	if ( dir == REEL )
	{
		OCR1B = val;
		OCR1A = 0;
	}
	else if ( dir == SPOOL )
	{
		OCR1A = val;
		OCR1B = 0;
	}
	else
	{
		return;
	}
	TCCR1B = (1 << CS10)  | (1 << WGM12);
	TCCR1A = (1 << COM1A1)|(1 << COM1B1)| (1 << WGM11);

}

void PWM_Stop( void )
{

	TCCR1A = 0;
	TCCR1B = 0;
	// PWM PIN NEEDS TO BE LOW HERE
	PORTB &= ~_BV( PB1 );
	PORTB &= ~_BV( PB2 );
}

int Blocking_Switch_Wait()
{
	while( 1 )
	{
		if( ! (PINB & _BV( PB5 ) )) return REEL_SLOW;
		if( ! (PINB & _BV( PB4 ) )) return REEL_FAST;
	}

}

int Check_Switchs()
{
	if( ! (PINB & _BV( PB5  ) )) return REEL_SLOW;
	if( ! (PINB & _BV( PB4  ) )) return REEL_FAST;
	if( ! (PINB & _BV( PB3  ) )) return REEL_REVERSE;
    return FALSE;
}


void Motor_Disengaged_For_Spool( char state )
{
	if( state )
		PORTD &= ~_BV( PD4 );
	else
		PORTD |= _BV( PD4 );

}

// Opposite side of spool disengage
void Motor_Engage_For_Drive( char state )
{
	if( state )
		PORTD |= _BV( PD5 );
	else
		PORTD &= ~_BV( PD5 );

}

void Motor( char state )
{
	if( state == REV  )
		PORTB |= _BV( PB5 );
	else
		PORTB &= ~_BV( PB5 );
}

void Alarm( char state )
{
	if( state == ON  )
		PORTD |= _BV( PD7 );
	else
		PORTD &= ~_BV( PD7 );
}

void USART_Transmit(unsigned char data )
{
  /* Wait for empty transmit buffer */
  while ( !( UCSR0A & (1<<UDRE0)) )
    ;
  /* Put data into buffer, sends the data */
  UDR0 = data;
}

// write null terminated string
void serial_write_str(const char* str)
{
  int len = strlen(str);
  int i;
  for (i = 0; i < len; i++) {
    USART_Transmit(str[i]);
  }
}

// used pins on port C and D
#define LCD_E  2    // PORTD.2
#define LCD_RS 3    //PORTD.3   ------------
//#define LCD_RD 7    // PORTD.7
//#define LCD_WR 6    // PORTD.6
// Data and Busy flag are on PORTA

#define LCD_DB4  5  // PORTC.5
#define LCD_DB5  4  // PORTC.4
#define LCD_DB6  3  // PORTC.3
#define LCD_DB7  2  // PORTC.2
//LCD commands
#define LCD_CLR 0x01  // clear LCD
#define LCD_4BIT 0x32 // 8-bit mode
#define LCD_INC 0x06  //Increment, display freeze
#define LCD_MOV 0x10  //Cursor move, not shift
#define LCD_ALL  0x0F // LCD On, LCD display on, cursor on and blink on
#define LCD_ON           0x08      // turn lcd/cursor on
#define LCD_ON_DISPLAY   0x04      // turn display on
#define LCD_ON_CURSOR    0x02      // turn cursor on
#define LCD_ON_BLINK     0x01      // cursor blink
#define LCD_LINE1  0x80        // cursor Pos on line 1 (or with column)
#define LCD_LINE2  0xC0        // cursor Pos on line 2 (or with column)

void LCD_wait(void){
	//get address and busy flag
	//and loop until busy flag (bit7) cleared
	sleepms(5);
//	while((LCD_getaddr() & 0x80) == 0x80)
//	{
 //       }
}

/*LCD_putchar writes a character to the LCD at the current address,
usage: LCD_putchar('A'); or LCD_putchar(0x55); */

void nopDelay( void )
{
	asm volatile ("nop");
	asm volatile ("nop");
	asm volatile ("nop");
	asm volatile ("nop");

}

void LCD_putchar(unsigned char data){
	LCD_wait();  // is it busy?
	LCD_wait();  // is it still busy?
	PORTD |= (1<<LCD_RS);  //RS high for data
	sleepms(5);
	PORTC &= ~((1<<LCD_DB7)|(1<<LCD_DB6)|(1<<LCD_DB5)|(1<<LCD_DB4));
	if( data & 0x80 ) PORTC |= _BV( LCD_DB7 );
	if( data & 0x40 ) PORTC |= _BV( LCD_DB6 );
	if( data & 0x20 ) PORTC |= _BV( LCD_DB5 );
	if( data & 0x10 ) PORTC |= _BV( LCD_DB4 );
	nopDelay( );
	PORTD |= (1<<LCD_E);    //Enable pin high
	nopDelay( );
	PORTD &= ~(1<<LCD_E);   //Enable Pin Low
	nopDelay( );
	PORTC &= ~((1<<LCD_DB7)|(1<<LCD_DB6)|(1<<LCD_DB5)|(1<<LCD_DB4));
	if( data & 0x08 ) PORTC |= _BV( LCD_DB7 );
	if( data & 0x04 ) PORTC |= _BV( LCD_DB6 );
	if( data & 0x02 ) PORTC |= _BV( LCD_DB5 );
	if( data & 0x01 ) PORTC |= _BV( LCD_DB4 );
	nopDelay( );
	PORTD |= (1<<LCD_E);    //Enable pin high
	nopDelay( );
	PORTD &= ~(1<<LCD_E);   //Enable Pin Low
	nopDelay( );
}
/*LCD_command works EXACTLY like LCD_putchar, but takes RS low for
accessing the command reg */

void LCD_half_command(unsigned char command){

	LCD_wait();  // is it still busy?
	PORTD &= ~(1<<LCD_RS);  //RS low for Command
	PORTC &= ~((1<<LCD_DB7)|(1<<LCD_DB6)|(1<<LCD_DB5)|(1<<LCD_DB4));
	if( command & 0x80 ) PORTC |= _BV( LCD_DB7 );
	if( command & 0x40 ) PORTC |= _BV( LCD_DB6 );
	if( command & 0x20 ) PORTC |= _BV( LCD_DB5 );
	if( command & 0x10 ) PORTC |= _BV( LCD_DB4 );
	nopDelay( );
	PORTD |= (1<<LCD_E);    //Enable pin high
	nopDelay( );
	PORTD &= ~(1<<LCD_E);   //Enable Pin Low
	nopDelay( );
}


void LCD_command(unsigned char command){

	LCD_wait();  // is it still busy?
	PORTD &= ~(1<<LCD_RS);  //RS low for Command
	PORTC &= ~((1<<LCD_DB7)|(1<<LCD_DB6)|(1<<LCD_DB5)|(1<<LCD_DB4));
	if( command & 0x80 ) PORTC |= _BV( LCD_DB7 );
	if( command & 0x40 ) PORTC |= _BV( LCD_DB6 );
	if( command & 0x20 ) PORTC |= _BV( LCD_DB5 );
	if( command & 0x10 ) PORTC |= _BV( LCD_DB4 );
	nopDelay( );
	PORTD |= (1<<LCD_E);    //Enable pin high
	nopDelay( );
	PORTD &= ~(1<<LCD_E);   //Enable Pin Low
	nopDelay( );
	PORTC &= ~((1<<LCD_DB7)|(1<<LCD_DB6)|(1<<LCD_DB5)|(1<<LCD_DB4));
	if( command & 0x08 ) PORTC |= _BV( LCD_DB7 );
	if( command & 0x04 ) PORTC |= _BV( LCD_DB6 );
	if( command & 0x02 ) PORTC |= _BV( LCD_DB5 );
	if( command & 0x01 ) PORTC |= _BV( LCD_DB4 );
	nopDelay( );
	PORTD |= (1<<LCD_E);    //Enable pin high
	nopDelay( );
	PORTD &= ~(1<<LCD_E);   //Enable Pin Low
	nopDelay( );
}

/*LCD_init initialises the LCD with the following paramters:
8 bit mode, 5*7 font, 2 lines (also for 4 lines)
auto-inc cursor after write and read
cursor and display on, cursor blinking.*/

void LCD_init(void){
	//setup the LCD control signals on PortC  (RS and Enable as output)
	DDRD |= ((1<<LCD_RS)|(1<<LCD_E));
	PORTD &= ~((1<<LCD_RS)|(1<<LCD_E));// set both low
	DDRC = ((1<<LCD_DB7)|(1<<LCD_DB6)|(1<<LCD_DB5)|(1<<LCD_DB4));
	PORTC &= ~((1<<LCD_DB7)|(1<<LCD_DB6)|(1<<LCD_DB5)|(1<<LCD_DB4));

	sleepms(10);
	LCD_half_command(0x30);
	sleepms(10);
	LCD_half_command(0x30);
	sleepms(10);
	LCD_half_command(0x30);
	sleepms(10);
	LCD_half_command(0x20);
	sleepms(10);
	LCD_command(0x28);
	sleepms(5);
	LCD_command(0x08);
	sleepms(5);
	LCD_command(0x01);
	sleepms(5);
	LCD_command(0x0C);   // on
	sleepms(5);
}

// function for showing strings on the LCD. It uses the low-level
//functions above. usage example: LCD_write("Hello World!");

void LCD_write(char* dstring){

	//is the character pointed at by dstring a zero? If not, write character to LCD
	while(*dstring)
	{
	// write the character from dstring to the LCD, then post-inc the string pointer.
	       LCD_putchar(*dstring++);
	}
}

/**************************************************************************************************
 * \fn 			int main(void)
 * \brief       Serial -> STX, CMD, VAL, DIV, ETX
 *              Uses systick for comms failure.
 *              02 a1 aa 03 03 Test string
 * \param[in]
 * \return
 *************************************************************************************************/

void sleepms( int ms )
{
	int n;

	while( ms-- )
	{
		for( n=0;n<650;n++ );
	}

}

int main(void)
{
    uint8_t result;
    uint8_t n;
    uint8_t trip;
    uint16_t adc_result;
    uint16_t adc_result_initial;
    uint16_t ramp;
    char buffer[50];
    uint16_t loop;

//#define LCD 0

#ifdef LCD
    sleepms(100);
    LCD_init();
    LCD_write("GrippaTank");
    while(1)
    {
    	sleepms(50);
    }
#endif

    HW_Init();
	sleepms(500);

	Led( NONE_ALL_OFF, OFF );
	sleepms(300);
	Led( RED, ON );
	sleepms(300);
	Led( YELLOW, ON );
	sleepms(300);
	Led( GREEN, ON );
	sleepms(300);
	Led( GREEN, OFF );
	sleepms(300);
	Led( YELLOW, OFF );
	sleepms(300);
    adc_init();

	USART_Init( UBRR_VALUE_38400 );
	Led( RED, ON );

	sleepms(500);

#if CTC_WITH_INTERRURT
    TCCR1A |= (1 << COM1A0);
    TCNT1 = 0;
    TCCR1B = (1 << WGM12)|(1 << CS10);
    OCR1A = 999;

    TIFR |= (1<<OCF1A);
    TIMSK|=(1<<OCIE1A);
#endif
#if 0
        // fast PWM mode
    TCCR1A = 0xA0 | (1 << WGM10);
    TCCR1B = ( 1 << WGM12 ) | (1 << CS11);   // clock source = CLK/1, start PWM
    TCNT1 = 0xFF;
    OCR1A  = 0x100;

    TIFR |= (1<<TOV1);
    TIMSK|=(1<<TOIE1);32

#endif
 //   sei();

    serial_write_str("Reel Controller V 1.0.0\n\r");

#define ADC_THRESHOLD	500

#define CURRENT_13A  240
#define CURRENT_10A 313
#define CURRENT_9A 340
#define CURRENT_8A 360

    Motor_Disengaged_For_Spool( TRUE );
    Motor_Engage_For_Drive( FALSE );
    loop = 0;
    while(1)
    {
// TODO - check for dead short current
    	result = Check_Switchs();

    	if ( result == REEL_FAST )
    	{
    		Motor_Engage_For_Drive( TRUE );
    		Motor_Disengaged_For_Spool( FALSE );
    		serial_write_str("Reel Fast\n\r");
    //		Motor( FWD );
			// Start PWM
    		adc_result = ReadADC(7);

    		// cap at 1us
    		if( adc_result > 505 )
    		{
    			adc_result = 505;
    		}

    		adc_result_initial = adc_result;
    		sprintf( buffer, "FAST => Speed Control ADC => %i\n\r", adc_result );
        	serial_write_str( buffer );

			Led( YELLOW, ON );

        	ramp = 0x10;
//    		while ( ramp < adc_result )
 //   		{
 //   			PWM_Start( ramp, REEL );
 //   			_delay_ms(10);
 //   			if ( ( ramp + 0x5 ) >= adc_result ) break;
 //   			ramp += 0x5;
 //   		}

    		trip = 0;
    		while( Check_Switchs() == REEL_FAST )
    		{
    			if ( ramp < adc_result_initial )
    			{
    				PWM_Start( ramp, REEL );
    				//_delay_ms(10);
    				if ( ( ramp + 0x5 ) < adc_result_initial )
    				{
    					ramp += 0x5;
    				}
    			}

        		Alarm( OFF );
        		adc_result = ReadADC(6);
        		sprintf( buffer, "FAST => ADC Batt => %i\n\r", adc_result );
            	serial_write_str( buffer );
            	if( adc_result < 760 )
            	{
            		/* If the hose is snagged instantaneously the battery rail can drop preventing the ADC current device from
            		 doing its job properly - check supply here */

            		trip = 10;
            		sprintf( buffer, "WARNING Battery condition = Shutting down [ trip %i ]\n\r", trip );
                	serial_write_str( buffer );
            	}
            	sleepms(10);
        		adc_result = ReadADC(0);
        		sprintf( buffer, "FAST => I ASC712 => %i\n\r", adc_result );
            	serial_write_str( buffer );
            	if ( adc_result <= CURRENT_13A )
            	{
            		Alarm( ON );
            		sprintf( buffer, "WARNING Excessive current [ trip %i ]\n\r", trip );
                	serial_write_str( buffer );
                	trip++;
            	}
            	if ( trip >= 10 )
            	{
            		sprintf( buffer, "WARNING Excessive current = Shutting down [ trip %i ]\n\r", trip );
                	serial_write_str( buffer );

            		PWM_Stop();
            		Led( YELLOW, OFF );
            		Motor_Disengaged_For_Spool( TRUE );
            		Motor_Engage_For_Drive( FALSE );

                	while( Check_Switchs() == REEL_FAST )
                	{
                		Alarm( ON );
                		sleepms(100);
                		Alarm( OFF );
                	}
                	break;
            	}
    		}
    		Alarm( OFF );
    		if ( trip < 10 )
    		{
    			PWM_Stop();
    			Led( YELLOW, OFF );
    			Motor_Disengaged_For_Spool( TRUE );
    			Motor_Engage_For_Drive( FALSE );
    		}
    //		while( ReadADC(0)  > 100 );
    	}
    	else if ( result == REEL_SLOW )
    	{
#define SLOW_PWM 0xDF

// TODO - check for dead short current

    		Motor_Engage_For_Drive( TRUE );
    		Motor_Disengaged_For_Spool( FALSE );
    		serial_write_str("Reel Slow\n\r");
    //		Motor( FWD );
			// Start PWM

    		sprintf( buffer, "Slow => Speed Control Fixed => %i\n\r", SLOW_PWM );
        	serial_write_str( buffer );

			Led( YELLOW, ON );

        	ramp = 0x10;
 //   		while ( ramp < SLOW_PWM )
 //   		{
 //   			PWM_Start( ramp, REEL );
 //   			_delay_ms(10);
 //   			if ( ( ramp + 0x5 ) >= SLOW_PWM ) break;
 //   			ramp += 0x5;
 //   		}

    		trip = 0;
    		while( Check_Switchs() == REEL_SLOW )
    		{
    			if ( ramp < SLOW_PWM )
    			{
    				PWM_Start( ramp, REEL );
    				//_delay_ms(10);
    				if ( ( ramp + 0x5 ) < SLOW_PWM )
    				{
    					ramp += 0x5;
    				}
    			}

    			Alarm( OFF );
    			sleepms(10);
        		adc_result = ReadADC(0);
        		sprintf( buffer, "SLOW => I ASC712 => %i\n\r", adc_result );
            	serial_write_str( buffer );
            	if ( adc_result <= CURRENT_8A )
            	{
            		Alarm( ON );
            		sprintf( buffer, "WARNING Excessive current [ trip %i ]\n\r", trip );
                	serial_write_str( buffer );
                	trip++;
            	}
            	if ( trip >= 10 )
            	{
            		sprintf( buffer, "WARNING Excessive current = Shutting down [ trip %i ]\n\r", trip );
                	serial_write_str( buffer );

            		PWM_Stop();
            		Led( YELLOW, OFF );
            		Motor_Disengaged_For_Spool( TRUE );
            		Motor_Engage_For_Drive( FALSE );

                	while( Check_Switchs() == REEL_SLOW )
                	{
                		Alarm( ON );
                		sleepms(100);
                		Alarm( OFF );
                	}
                	break;
            	}
    		}
    		Alarm( OFF );
    		if ( trip < 10 )
    		{
    			PWM_Stop();
    			Led( YELLOW, OFF );
    			Motor_Disengaged_For_Spool( TRUE );
    			Motor_Engage_For_Drive( FALSE );
    		}
    //		while( ReadADC(0)  > 100 );
    	}
    	else if ( result == REEL_REVERSE )
    	{
    		Motor_Engage_For_Drive( TRUE );
    		Motor_Disengaged_For_Spool( FALSE );
    		sprintf( buffer, "Reverse => Speed Control Fixed => %i\n\r", SLOW_PWM );
        	serial_write_str( buffer );
//    		Motor( REV );

        	Led( GREEN, ON);
        	//==================================
        	ramp = 0x10;

    		trip = 0;
    		while( Check_Switchs() == REEL_REVERSE )
    		{
    			if ( ramp < SLOW_PWM )
    			{
    				PWM_Start( ramp, SPOOL );
    				//_delay_ms(10);
    				if ( ( ramp + 0x5 ) < SLOW_PWM )
    				{
    					ramp += 0x5;
    				}
    			}

    			Alarm( OFF );
    			sleepms(10);
        		adc_result = ReadADC(0);
        		sprintf( buffer, "Reverse => I ASC712 => %i\n\r", adc_result );
            	serial_write_str( buffer );
            	if ( adc_result <= CURRENT_8A )
            	{
            		Alarm( ON );
            		sprintf( buffer, "WARNING Excessive current [ trip %i ]\n\r", trip );
                	serial_write_str( buffer );
                	trip++;
            	}
            	if ( trip >= 10 )
            	{
            		sprintf( buffer, "WARNING Excessive current = Shutting down [ trip %i ]\n\r", trip );
                	serial_write_str( buffer );

            		PWM_Stop();
            		Led( GREEN, OFF );
            		Motor_Disengaged_For_Spool( TRUE );
            		Motor_Engage_For_Drive( FALSE );

                	while( Check_Switchs() == REEL_REVERSE )
                	{
                		Alarm( ON );
                		sleepms(100);
                		Alarm( OFF );
                	}
                	break;
            	}
    		}
    		Alarm( OFF );
    		if ( trip < 10 )
    		{
    			PWM_Stop();
    			Led( GREEN, OFF );
    			Motor_Disengaged_For_Spool( TRUE );
    			Motor_Engage_For_Drive( FALSE );
    		}




        	//=======================================

			// Start PWMHi Moday
//			PWM_Start( 0x140, SPOOL );
 //   		Led( GREEN, ON);
  //  		sleepms(1000);
			// Stop PWM
//			PWM_Stop();
//			Led( GREEN, OFF );
//			Motor_Engage_For_Drive( FALSE );
//			Motor_Disengaged_For_Spool( TRUE );
//			sleepms(600);


    	}
//    	adc_result = ReadADC(1);
 //   	if( adc_result > 300 )
 //   	{
 //   		Motor_Disengaged_For_Spool( FALSE );
 //   		serial_write_str("Pulled\n\r");
 //   		sprintf( buffer, "ADC => %i\n\r", adc_result );
 //   		serial_write_str( buffer );
 ///   	}
#if 0
    	else if ( result == REV )
    	{
    		Motor_Disengaged_For_Spool( FALSE );
    		serial_write_str("Go\n\r");
    		Motor( REV );

			// Start PWM
			PWM_Start( 0x0F0 );
			Led( ON );
			_delay_ms(3000);
			// Stop PWM
			PWM_Stop();

    		//_delay_ms(10);
			//PORTB &= ~_BV( PB1 );
			Marker( HIGH );
			Marker( LOW );
			Motor_Disengaged_For_Spool( TRUE );

			for( n=0; n< 40; n++ )
			{
				_delay_ms(100);
				adc_result = ReadADC(0);
				sprintf( buffer, "ADC => %i\n\r", adc_result );
				serial_write_str( buffer );

			}
			Led( OFF );
    	}
#endif
#if 1
    	adc_result = ReadADC(1);
    	if( adc_result > 900 )
    	{
    		Motor_Engage_For_Drive( TRUE );
    		Motor_Disengaged_For_Spool( FALSE );
    		serial_write_str("Pulled [900]\n\r");
    		sprintf( buffer, "ADC => %i\n\r", adc_result );
    		serial_write_str( buffer );

//    		Motor( REV );

			// Start PWMHi Moday
			PWM_Start( 0x1F0, SPOOL );
    		Led( GREEN, ON );
    		sleepms(1000);
			// Stop PWM
			PWM_Stop();
			Led( GREEN, OFF );
			Motor_Engage_For_Drive( FALSE );
			Motor_Disengaged_For_Spool( TRUE );
			sleepms(1000);
    	} else if ( adc_result > 600 )
    	{
    		Motor_Engage_For_Drive( TRUE );
    		Motor_Disengaged_For_Spool( FALSE );
    		serial_write_str("Pulled [600]\n\r");
    		sprintf( buffer, "ADC => %i\n\r", adc_result );
    		serial_write_str( buffer );
//    		Motor( REV );

			// Start PWMHi Moday
			PWM_Start( 0x170, SPOOL );
    		Led( GREEN, ON);
    		sleepms(1000);
			// Stop PWM
			PWM_Stop();
			Led( GREEN, OFF );
			Motor_Engage_For_Drive( FALSE );
			Motor_Disengaged_For_Spool( TRUE );
			sleepms(800);
    	}else if ( adc_result > 400 )
    	{
    		Motor_Engage_For_Drive( TRUE );
    		Motor_Disengaged_For_Spool( FALSE );
    		serial_write_str("Pulled [400] \n\r");
    		sprintf( buffer, "ADC => %i\n\r", adc_result );
    		serial_write_str( buffer );
//    		Motor( REV );

			// Start PWMHi Moday
			PWM_Start( 0x140, SPOOL );
    		Led( GREEN, ON);
    		sleepms(1000);
			// Stop PWM
			PWM_Stop();
			Led( GREEN, OFF );
			Motor_Engage_For_Drive( FALSE );
			Motor_Disengaged_For_Spool( TRUE );
			sleepms(600);
    	}
    	else if ( adc_result > 300 )
    	{
    		Motor_Engage_For_Drive( TRUE );
    		Motor_Disengaged_For_Spool( FALSE );
    		serial_write_str("Pulled [300]\n\r");
    		sprintf( buffer, "ADC => %i\n\r", adc_result );
    		serial_write_str( buffer );
 //   		Motor( REV );

			// Start PWMHi Moday
			PWM_Start( 0x100, SPOOL );
    		Led( GREEN, ON );
    		sleepms(1000);
			// Stop PWM
			PWM_Stop();
			Led( GREEN, OFF );
			Motor_Engage_For_Drive( FALSE );
			Motor_Disengaged_For_Spool( TRUE );
			sleepms(500);
    	}
#endif

    }









}

/**************************************************************************************************
 * \fn 			void HW_Init( void )
 * \brief
 * \param[in]
 * \return
 *************************************************************************************************/
void HW_Init( void )
{

/* PORTB [7]xtal, [6]xtal, [5]RDF.0, [4]RDF.1, [3]RDF.2, [2]PWM, [1]PWM, [0]RDF.3 */
	DDRB = 0x06;
	PORTB = 0x00;

/* PORTC [7]N.A, [6]Reset, [5]LCD, [4]LCD/Red LED. [3]LCD/Yellow LED, [2]LCD/Green LED, [1]Spool ADC, [0]Current sense ADC  */
	DDRC = 0x1C;
	PORTC = 0x00;

/* PORTD [7]Buzzer, [6]SMod switch, [5]Shutdown PWM, [4]Shutdown PWM, [3]LCD, [2]LCD, [1]UART-tx, [0]UART-rx */
	DDRD = 0xB2;
	PORTD = 0x00;
	/* Enable the ADC */
	ADCSRA |= _BV(ADEN);

//	InitINT1();
}

/* eof */
